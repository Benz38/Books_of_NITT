import sqlite3
from flask import Flask, render_template, request
from flask import redirect, url_for, send_file
from io import BytesIO
from flask_wtf.file import FileField
from wtforms import SubmitField
from flask_wtf import Form
from flask_sqlalchemy import SQLAlchemy
from flask_mysqldb import MySQL
print("All modules loaded...")
# except:
#     print("Some module missing...")

app = Flask(__name__)  # creating the Flask class object
app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///YTD.db"
app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///deepak.db"
app.config['SQLALCHEMY_TRACK_MODIFICATION'] = False
app.config["SECRET_KEY"] = "secret"
db = SQLAlchemy(app)
app.app_context().push()

class user(db.Model):
    name=db.Column(db.String,primary_key=True)
    age=db.Column(db.Integer,nullable=True)
    
    def __repr__(self):
        return f"user('{self.name}',{self.age})"\
        
    
@app.route('/upload', methods=["GET", "POST"])
def upload():

    form = UploadForm()
    if request.method == "POST":
        if form.validate():
            file_name = form.file.data
            print(form.file.data)
            database(name=file_name.filename, data=file_name.read() )
            return render_template("home.html", form=form)
    return render_template("home.html", form=form)


@app.route('/download', methods=["GET", "POST"])
def download():

    form = UploadForm()

    if request.method == "POST":

        conn= sqlite3.connect("YTD.db")
        cursor = conn.cursor()
        print("IN DATABASE FUNCTION ")
        c = cursor.execute(""" SELECT * FROM  my_table """)

        for x in c.fetchall():
            name_v=x[0]
            data_v=x[1]
            break

        conn.commit()
        cursor.close()
        conn.close()

        return send_file(BytesIO(data_v), attachment_filename='flask.pdf', as_attachment=True)


    return render_template("home.html", form=form)




class UploadForm(Form):
    file = FileField()
    submit = SubmitField("submit")
    download = SubmitField("download")

def database(name, data):
    conn= sqlite3.connect("YTD.db")
    cursor = conn.cursor()

    cursor.execute("""CREATE TABLE IF NOT EXISTS my_table (name TEXT,data BLOP) """)
    cursor.execute("""INSERT INTO my_table (name, data) VALUES (?,?) """,(name,data))

    conn.commit()
    cursor.close()
    conn.close()



def query():
        conn= sqlite3.connect("YTD.db")
        cursor = conn.cursor()
        print("IN DATABASE FUNCTION ")
        c = cursor.execute(""" SELECT * FROM  my_table """)

        for x in c.fetchall():
            name_v=x[0]
            data_v=x[1]
            break

        conn.commit()
        cursor.close()
        conn.close()

        return send_file(BytesIO(data_v), attachment_filename='flask.pdf', as_attachment=True)





# class UploadForm(Form):
#     file = FileField()
#     submit = SubmitField("submit")
#     download = SubmitField("download")



# @app.route('/upload' , methods=["GET" , "POST"])  
# def upload():

#     form = UploadForm()
#     if request.method == "POST":

#         if form.validate_on_submit():
#             file_name = form.file.data
#             database(name=file_name.filename, data = file_name.read() )
#             return render_template("home.html", form=form)
#     return render_template("home.html", form = form)

# @app.route('/upload', methods=["GET", "POST"])
# def upload():
   
#     if request.method=='POST':
#        file=request.files['file']
#        print(file)
#     return render_template('home.html')
    

# def database():
#     conn = sqlite3.connect("YTD.db")
#     cursor=conn.cursor()

#     cursor.execute(""" CREATE TABLE IF NOT EXISTS my_table(name TEXT, data BLOP) """)
#     cursor.execute(""" INSERT INTO my_table(name, data) VALUES (?, ?) """, (name, data))

#     conn.commit()
#     cursor.close()
#     conn.close()

    






@app.route('/')  # decorator defines the
def index():
    return render_template('index.html')

@app.route('/form.html')
def form():
    return render_template('form.html')
    
@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method=='POST':
        name=request.form['name']
        age=request.form['age']
        post=user(name=name,age=age)
        db.session.add(post)
        db.session.commit()
    return render_template('success.html')



@app.route('/mca.html')  # decorator defines the
def mca():
    return render_template('mca.html')

@app.route('/sem1.html')  # decorator defines the
def sem1():
    return render_template('sem1.html')

@app.route('/about.html')  # decorator defines the
def about():
    return render_template('about.html', name= "Deepak")

@app.route('/material.html')  # decorator defines the
def material():
    return render_template('material.html')

@app.route('/show')  # decorator defines the
def show():
    all_data= user.query.all()
    print(all_data)
    return 'all the datta is here'
    


if __name__ == '__main__':
    db.create_all()
    app.run(debug=True,port=8000)